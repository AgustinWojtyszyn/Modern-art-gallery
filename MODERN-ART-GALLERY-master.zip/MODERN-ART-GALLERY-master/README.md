#  Art gallery website

## Links
Live site URL :  [Github Pages](https://annepatchkoria.github.io/MODERN-ART-GALLERY/index.html)


![Design preview for the Art gallery website coding challenge](./preview.jpg)
![Design preview for the Art gallery website coding challenge](./art-gallery.jpg)



